
chrome.tabs.getSelected(null,function(tab) {
  main(tab.url);
});
function main(url)
{
  var req = new XMLHttpRequest();
  req.open("GET", "http://tinyurl.com/api-create.php?url=" + url, true);
  req.addEventListener("load", function(e) {
		var result = req.responseText;
		var tinyurl = document.getElementById("tinyurl");
		tinyurl.innerHTML = req.responseText;
		var button = document.getElementById("copy");
        button.innerHTML = "Copy";
        button.addEventListener("click", function() { button.innerHTML = ""; copyToClipboard(); button.innerHTML = "Copy"; }, false); 
  }, false)
  req.send();
}
function copyToClipboard()
{ 
  document.execCommand('SelectAll');
  document.execCommand("Copy", false, null);
  document.execCommand('UnSelect');
  chrome.tabs.getSelected(null, function(tab) {
    chrome.tabs.update(tab.id, { selected: true } )
  });
}